# rekweb2020_183040064_omdb
tugas praktikum rekweb tentang movie menggunakan api omdb
